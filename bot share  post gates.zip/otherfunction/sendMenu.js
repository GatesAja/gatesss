const fs = require("fs")
const { ActionRowBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle } = require("discord.js")
const { NamaBot, OwnerID } = require("../settings.js")
let itemPage = 24
module.exports = async function(embed, interaction, page, bool, client) {
  let Channel = JSON.parse(fs.readFileSync("./Database/Channel.json"))
  let totalPages = Math.ceil(Channel.length / itemPage)
    const start = (page - 1) * itemPage
    const itemsPage = Channel.slice(start, start + itemPage)
let options = itemsPage.map(item =>
    new StringSelectMenuOptionBuilder()
        .setLabel(item.name)
        .setValue(`item_${item.channelid}`)
        .setDescription(`ID: ${item.channelid}`),
)
    if (page > 1) {
        options.unshift({ label: '⬅️ Previous', value: `prev_${page}` });
    }
    if (page < totalPages) {
        options.push({ label: '➡️ Next', value: `next_${page}` });
    }
    const selectMenu = new StringSelectMenuBuilder()
        .setCustomId('listchannelmenu')
        .setPlaceholder('Pilih Channel...')
        .addOptions(options)
        const row = new ActionRowBuilder().addComponents(selectMenu)
      await interaction.reply({
        embeds: [embed],
        components: [row]
      })
      if (bool) {
        let embedFolup = new EmbedBuilder()
    .setColor("Blue")
    .setTitle("Pengaturan Tambahan")
    .setDescription("Klik tombol dibawah ini untuk start all atau stop all")
    .setTimestamp()
    .setFooter({text: NamaBot, iconURL: client.user.displayAvatarURL()})
    let btn1 = new ButtonBuilder()
    .setCustomId("startall")
    .setLabel("Start All")
    .setStyle(ButtonStyle.Success)
    let btn2 = new ButtonBuilder()
    .setCustomId("stopall")
    .setLabel("Stop All")
    .setStyle(ButtonStyle.Danger)
    let bttn = new ActionRowBuilder().addComponents([btn1, btn2])
    await interaction.followUp({
      embeds: [embedFolup],
      components: [bttn]
    })
      }
}