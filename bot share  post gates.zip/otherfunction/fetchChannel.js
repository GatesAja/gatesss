const fs = require("fs")
const axios = require("axios")
const fetchChannelByID = async (channelid) => {
  const Main = JSON.parse(fs.readFileSync("./Database/Main.json"))
    try {
        const response = await axios.get(`https://discord.com/api/v10/channels/${channelid}`, {
            headers: {
                'Authorization': Main.token,
                'Content-Type': 'application/json'
            }
        });

        return response.data
    } catch (error) {
        console.error('Error fetching channel:', error.response ? error.response.data : error.message)
    }

}
module.exports = { fetchChannelByID }