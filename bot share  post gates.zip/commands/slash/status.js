const { SlashCommandBuilder, EmbedBuilder } = require("discord.js")
const { NamaBot, OwnerID } = require("../../settings.js")
const fs = require("fs")

module.exports = {
  data: new SlashCommandBuilder()
  .setName("status")
  .setDescription("Cek status auto post"),
  async execute(interaction, client) {
    const embedGagal = new EmbedBuilder()
    .setColor("Red")
    .setTitle("<:silang:1354994994087329924> Akses Ditolak")
    .setDescription(`Hanya owner yang bisa mengakses perintah ini!`)
    .setTimestamp()
    .setFooter({text: NamaBot, iconURL: client.user.displayAvatarURL()})
    if (interaction.user.id !== OwnerID) return await interaction.reply({
      embeds: [embedGagal],
      ephemeral: true
    })
    let Data = JSON.parse(fs.readFileSync("./Database/Main.json"))
    let Channel = JSON.parse(fs.readFileSync("./Database/Channel.json"))
    let aktif = 0
    let mati = 0
    if (Channel.length !== 0) {
    Object.keys(Channel).forEach((h) => {
      if (Channel[h].status === true) aktif++
      else mati++
    })
    }
    const embedStatus = new EmbedBuilder()
    .setTitle("Status Auto Post")
    .setDescription(`**- Token:** ${Data.token ? "MENYAMBUNG" : "TIDAK MENYAMBUNG"}
**- Webhook:** ${Data.webhookurl ? "MENYAMBUNG" : "TIDAK MENYAMBUNG"}
**- Total Channel:** ${Channel.length}
**- Aktif:** ${aktif}
**- Mati:** ${mati}`)
.setTimestamp()
.setColor("Blue")
.setFooter({text: NamaBot, iconURL: client.user.displayAvatarURL()})
await interaction.reply({
  embeds: [embedStatus]
})
  }
}