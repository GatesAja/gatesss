const { SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require("discord.js")
const { NamaBot, OwnerID } = require("../../settings.js")
const fs = require("fs")
const { fetchChannelByID } = require("../../otherfunction/fetchChannel.js")

module.exports = {
  data: new SlashCommandBuilder()
  .setName("addchannel")
  .setDescription("Tambahkan channel untuk auto post"),
  async execute(interaction, client) {
    const embedGagal = new EmbedBuilder()
    .setColor("Red")
    .setTitle("<:silang:1354994994087329924> Akses Ditolak")
    .setDescription(`Hanya owner yang bisa mengakses perintah ini!`)
    .setTimestamp()
    .setFooter({text: NamaBot, iconURL: client.user.displayAvatarURL()})
    if (interaction.user.id !== OwnerID) return await interaction.reply({
      embeds: [embedGagal],
      ephemeral: true
    })
    let addEmbed = new EmbedBuilder()
    .setColor("Blue")
    .setTitle("Add Channel Auto-Post")
    .setDescription(`Klik tombol dibawah ini untuk menambahkan channel pada auto post

<:book:1355026320941256724> Petunjuk:
- Pastikan kamu memiliki izin pada channel tujuan
- Minimum interval adalah 3600 Detik
- Jika interval dibawah 3600, maka otomatis akan menyesuaikan slowmode channel`)
.setTimestamp()
.setFooter({text: NamaBot, iconURL: client.user.displayAvatarURL()})
let button = new ButtonBuilder()
.setCustomId("inputchannel")
.setLabel("Tambah Channel")
.setStyle(ButtonStyle.Primary)
const btn = new ActionRowBuilder().addComponents(button)
await interaction.reply({
  embeds: [addEmbed],
  components: [btn]
})
  }
}