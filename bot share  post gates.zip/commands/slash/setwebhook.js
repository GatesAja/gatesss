const { SlashCommandBuilder, EmbedBuilder } = require("discord.js")
const { NamaBot, OwnerID } = require("../../settings.js")
const fs = require("fs")

module.exports = {
  data: new SlashCommandBuilder()
  .setName("setwebhook")
  .setDescription("Set webhook url untuk auto post")
  .addStringOption(option => option.setName("url").setDescription("Masukkan url webhookmu").setRequired(true)),
  async execute(interaction, client) {
    const embedGagal = new EmbedBuilder()
    .setColor("Red")
    .setTitle("<:silang:1354994994087329924> Akses Ditolak")
    .setDescription(`Hanya owner yang bisa mengakses perintah ini!`)
    .setTimestamp()
    .setFooter({text: NamaBot, iconURL: client.user.displayAvatarURL()})
    if (interaction.user.id !== OwnerID) return await interaction.reply({
      embeds: [embedGagal],
      ephemeral: true
    })
    let Data = JSON.parse(fs.readFileSync("./Database/Main.json"))
    let Url = interaction.options.getString("url")
    const msgEmbed = new EmbedBuilder()
    .setColor("Green")
    .setTitle("<:ceklist:1354994363284852808> Set Webhook Berhasil")
    .setDescription(`Berhasil set webhook auto post.`)
    .setTimestamp()
    .setFooter({text: NamaBot, iconURL: client.user.displayAvatarURL()})
    await interaction.reply({
      embeds: [msgEmbed]
    })
    Data.webhookurl = Url
    fs.writeFileSync("./Database/Main.json", JSON.stringify(Data, null, 2))
  }
}