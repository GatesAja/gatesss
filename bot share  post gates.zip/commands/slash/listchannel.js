const { SlashCommandBuilder, EmbedBuilder, StringSelectMenuBuilder, ActionRowBuilder, StringSelectMenuOptionBuilder, ButtonBuilder, ButtonStyle } = require("discord.js")
const { NamaBot, OwnerID } = require("../../settings.js")
const fs = require("fs")
const sendMenu = require("../../otherfunction/sendMenu.js")


module.exports = {
  data: new SlashCommandBuilder()
  .setName("listchannel")
  .setDescription("List channel pada auto post"),
  async execute(interaction, client) {
    const embedGagal = new EmbedBuilder()
    .setColor("Red")
    .setTitle("<:silang:1354994994087329924> Akses Ditolak")
    .setDescription(`Hanya owner yang bisa mengakses perintah ini!`)
    .setTimestamp()
    .setFooter({text: NamaBot, iconURL: client.user.displayAvatarURL()})
    if (interaction.user.id !== OwnerID) return await interaction.reply({
      embeds: [embedGagal],
      ephemeral: true
    })
    let Channel = JSON.parse(fs.readFileSync("./Database/Channel.json"))
    let embedGgl = new EmbedBuilder()
    .setColor("Red")
    .setTitle("<:silang:1354994994087329924> Error!!")
    .setDescription(`Kamu belum menambahkan channel apapun!`)
    .setTimestamp()
    .setFooter({text: NamaBot, iconURL: client.user.displayAvatarURL()})
    if (Channel.length === 0) return await interaction.reply({
      embeds: [embedGgl]
    })
    let embedS = new EmbedBuilder()
    .setColor("Blue")
    .setTitle("List Channel Auto-Post")
    .setDescription(`Klik menu dibawah ini untuk memilih channel`)
.setTimestamp()
    .setFooter({text: NamaBot, iconURL: client.user.displayAvatarURL()})
    sendMenu(embedS, interaction, 1, true, client)
  }
}