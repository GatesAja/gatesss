const { SlashCommandBuilder, EmbedBuilder } = require("discord.js")
const { NamaBot, OwnerID } = require("../../settings.js")
const fs = require("fs")

module.exports = {
  data: new SlashCommandBuilder()
  .setName("settoken")
  .setDescription("Set token discord untuk auto post")
  .addStringOption(option => option.setName("token").setDescription("Masukkan token discordmu").setRequired(true)),
  async execute(interaction, client) {
    const embedGagal = new EmbedBuilder()
    .setColor("Red")
    .setTitle("<:silang:1354994994087329924> Akses Ditolak")
    .setDescription(`Hanya owner yang bisa mengakses perintah ini!`)
    .setTimestamp()
    .setFooter({text: NamaBot, iconURL: client.user.displayAvatarURL()})
    if (interaction.user.id !== OwnerID) return await interaction.reply({
      embeds: [embedGagal],
      ephemeral: true
    })
    let Data = JSON.parse(fs.readFileSync("./Database/Main.json"))
    let Token = interaction.options.getString("token")
    const msgEmbed = new EmbedBuilder()
    .setColor("Green")
    .setTitle("<:ceklist:1354994363284852808> Set Token Berhasil")
    .setDescription(`Berhasil set token auto post.`)
    .setTimestamp()
    .setFooter({text: NamaBot, iconURL: client.user.displayAvatarURL()})
    await interaction.reply({
      embeds: [msgEmbed]
    })
    Data.token = Token
    fs.writeFileSync("./Database/Main.json", JSON.stringify(Data, null, 2))
  }
}