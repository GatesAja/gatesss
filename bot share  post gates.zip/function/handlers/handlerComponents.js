const fs = require("fs")

module.exports = (client) => {
  client.handlerComponents = async () => {
    const folderComponents = fs.readdirSync("./components")
    for (let folder of folderComponents) {
      const fileComponents = fs.readdirSync(`./components/${folder}`).filter((file) => file.endsWith(".js"))
      const { buttons, selectMenus, modals } = client
      switch (folder) {
        case 'buttons': 
          for (let file of fileComponents) {
            const button = require(`../../components/${folder}/${file}`)
            buttons.set(button.data.name, button)
          }
          break
          case 'selectMenus':
            for (let file of fileComponents) {
              const menu = require(`../../components/${folder}/${file}`)
              selectMenus.set(menu.data.name, menu)
            }
          break
          case 'modals':
          for (let file of fileComponents) {
            const modal = require(`../../components/${folder}/${file}`)
            modals.set(modal.data.name, modal)
          }
          break
          default:
          break
      }
    }
  }
}