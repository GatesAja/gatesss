const fs = require("fs")

module.exports = (client) => {
  client.handlerEvents = async () => {
    const folderEvents = fs.readdirSync("./events")
    for (let folder of folderEvents) {
      const fileEvents = fs.readdirSync(`./events/${folder}`).filter((file) => file.endsWith(".js"))
      switch (folder) {
        case "client":
          for (let file of fileEvents) {
            const event = require(`../../events/${folder}/${file}`)
            if (event.once) client.once(event.name, (...args) => event.execute(...args, client))
            else client.on(event.name, (...args) => event.execute(...args, client))
          }
        break
        default:
        break
      }
    }
  }
}