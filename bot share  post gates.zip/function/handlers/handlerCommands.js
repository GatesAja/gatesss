const { REST } = require("@discordjs/rest")
const { Routes } = require("discord-api-types/v9")
const fs = require("fs")
const { TokenBot, ClientID } = require("../../settings.js")
const ora = require("ora")

module.exports = (client) => {
  client.handlerCommands = async () => {
    const folderCommand = fs.readdirSync("./commands")
    for (let folder of folderCommand) {
      const fileCommand = fs.readdirSync(`./commands/${folder}`).filter((file) => file.endsWith(".js"))
      const { commands, listCommand } = client
      for (let file of fileCommand) {
        const command = require(`../../commands/${folder}/${file}`)
        commands.set(command.data.name, command)
        listCommand.push(command.data.toJSON())
      }
    }
    const rest = new REST().setToken(TokenBot)
    try {
      await rest.put(Routes.applicationCommands(ClientID), {
        body: client.listCommand
      })
      const spinner = ora({
    text: 'Menghubungkan...',
    spinner: 'bouncingBar'
}).start()
setTimeout(() => {
    spinner.succeed('Terhubung')
}, 3000)
    } catch (error) {
      console.error(error)
    }
  }
}