const { EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder } = require("discord.js")
const fs = require("fs")
const { NamaBot, OwnerID } = require("../../settings.js")

module.exports = {
  data: {
    name: "listchannelmenu"
  },
  async execute(interaction, client) {
    const embedGagal = new EmbedBuilder()
    .setColor("Red")
    .setTitle("<:silang:1354994994087329924> Akses Ditolak")
    .setDescription(`Hanya owner yang bisa mengakses perintah ini!`)
    .setTimestamp()
    .setFooter({text: NamaBot, iconURL: client.user.displayAvatarURL()})
    if (interaction.user.id !== OwnerID) return await interaction.reply({
      embeds: [embedGagal],
      ephemeral: true
    })
    let selectedValue = interaction.values[0]
    let Channel = JSON.parse(fs.readFileSync("./Database/Channel.json"))
    let [action, pageOrId] = selectedValue.split('_')
    if (!pageOrId || isNaN(parseInt(pageOrId, 10))) {
        return interaction.reply({ content: '⚠️ Invalid selection!', ephemeral: true });
    }
    let page = parseInt(pageOrId, 10)
    let embedS = new EmbedBuilder()
    .setColor("Blue")
    .setTitle("List Channel Auto-Post")
    .setDescription(`Klik menu dibawah ini untuk memilih channel`)
.setTimestamp()
    .setFooter({text: NamaBot, iconURL: client.user.displayAvatarURL()})
    if (action === "next") {
      page++
      await sendMenu(embedS, interaction, page, false, client)
    } else if (action === "prev") {
      page--
      await sendMenu(embedS, interaction, page, false, client)
    } else {
      const item = Channel.find(i => i.channelid.toString() === pageOrId.toString())
        if (!item) {
            return interaction.reply({ content: '⚠️ Not Found!', ephemeral: true });
        }
        let hbtn
        let selectio = {
          channelid: item.channelid,
          name: item.name
        }
        fs.writeFileSync("./Database/Selection.json", JSON.stringify(selectio, null, 3))
        let embP = new EmbedBuilder()
        .setColor("Blue")
        .setTitle("<:mcdirt:1355007332886777946> Informasi Channel")
        .setDescription(`**Nama:** ${item.name}
**ID:** ${item.channelid}
**Status:** ${item.status ? "Aktif <:ceklist:1354994363284852808>" : "Nonaktif <:silang:1354994994087329924>"}

<:seru:1355091662954561536> Silahkan pilih menu dibawah ini sesuai kebutuhanmu!`)
if (item.status === true) {
hbtn = new ButtonBuilder()
.setCustomId("btnstop")
.setLabel("Stop")
.setStyle(ButtonStyle.Danger)
} else {
  hbtn = new ButtonBuilder()
.setCustomId("btnstart")
.setLabel("Start")
.setStyle(ButtonStyle.Success)
}
let btnedit = new ButtonBuilder()
.setCustomId("btnedit")
.setLabel("Edit")
.setStyle(ButtonStyle.Primary)
let btndelete = new ButtonBuilder()
.setCustomId("btndelete")
.setLabel("Delete")
.setStyle(ButtonStyle.Danger)
let buttons = new ActionRowBuilder().addComponents([hbtn, btnedit, btndelete])
await interaction.reply({
  embeds: [embP],
  components: [buttons]
})
    }
  }
}