const { EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require("discord.js")
const { NamaBot, OwnerID } = require("../../settings.js")
const fs = require("fs")

module.exports = {
  data: {
    name: "btnedit"
  },
  async execute(interaction, client) {
    const embedGagal = new EmbedBuilder()
    .setColor("Red")
    .setTitle("<:silang:1354994994087329924> Akses Ditolak")
    .setDescription(`Hanya owner yang bisa mengakses perintah ini!`)
    .setTimestamp()
    .setFooter({text: NamaBot, iconURL: client.user.displayAvatarURL()})
    if (interaction.user.id !== OwnerID) return await interaction.reply({
      embeds: [embedGagal],
      ephemeral: true
    })
    if (fs.existsSync("./Database/Selection.json")) {
      let Data = JSON.parse(fs.readFileSync("./Database/Selection.json"))
      let Channel = JSON.parse(fs.readFileSync("./Database/Channel.json"))
      let ps = null
      Object.keys(Channel).forEach((u) => {
        if (Channel[u].channelid === Data.channelid) ps = u
      })
      if (ps !== null) {
        if (Channel[ps].status === true) return await interaction.reply({
          embeds: [new EmbedBuilder()
    .setColor("Red")
    .setTitle("<:silang:1354994994087329924> Error!!")
    .setDescription(`Harap matikan auto post terlebih dahulu!`)
    .setTimestamp()
    .setFooter({text: NamaBot, iconURL: client.user.displayAvatarURL()})],
    ephemeral: true
        })
    let embP = new EmbedBuilder()
        .setColor("Blue")
        .setTitle("<:mcdirt:1355007332886777946> Informasi Channel")
        .setDescription(`**Nama:** ${Data.name}
**ID:** ${Data.channelid}
**Status:** ${Channel[ps].status ? "Aktif <:ceklist:1354994363284852808>" : "Nonaktif <:silang:1354994994087329924>"}

<:seru:1355091662954561536> Silahkan pilih menu dibawah ini sesuai kebutuhanmu!`)
let btnedit1 = new ButtonBuilder()
.setCustomId("btneditmessage")
.setLabel("Edit Message")
.setStyle(ButtonStyle.Secondary)
let btnedit2 = new ButtonBuilder()
.setCustomId("btneditdelay")
.setLabel("Edit Interval")
.setStyle(ButtonStyle.Secondary)
let btnback = new ButtonBuilder()
.setCustomId("btnback")
.setLabel("Back")
.setStyle(ButtonStyle.Primary)
let buttons = new ActionRowBuilder().addComponents([btnedit1, btnedit2, btnback])
await interaction.update({
  embeds: [embP],
  components: [buttons]
})
}
  }
  }
}