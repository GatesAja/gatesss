const { EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require("discord.js")
const { NamaBot, OwnerID } = require("../../settings.js")
const fs = require("fs")

module.exports = {
  data: {
    name: "stopall"
  },
  async execute(interaction, client) {
    const embedGagal = new EmbedBuilder()
    .setColor("Red")
    .setTitle("<:silang:1354994994087329924> Akses Ditolak")
    .setDescription(`Hanya owner yang bisa mengakses perintah ini!`)
    .setTimestamp()
    .setFooter({text: NamaBot, iconURL: client.user.displayAvatarURL()})
    if (interaction.user.id !== OwnerID) return await interaction.reply({
      embeds: [embedGagal],
      ephemeral: true
    })
    let Channel = JSON.parse(fs.readFileSync("./Database/Channel.json"))
    Object.keys(Channel).forEach((u) => {
      Channel[u].status = false
    })
    fs.writeFileSync("./Database/Channel.json", JSON.stringify(Channel, null, 3))
    let embedFolup = new EmbedBuilder()
    .setColor("Blue")
    .setTitle("Pengaturan Tambahan")
    .setDescription("Klik tombol dibawah ini untuk start all atau stop all")
    .setTimestamp()
    .setFooter({text: NamaBot, iconURL: client.user.displayAvatarURL()})
    let btn1 = new ButtonBuilder()
    .setCustomId("startall")
    .setLabel("Start All")
    .setStyle(ButtonStyle.Success)
    let btn2 = new ButtonBuilder()
    .setCustomId("stopall")
    .setLabel("Stop All")
    .setStyle(ButtonStyle.Danger)
    .setDisabled(true)
    let bttn = new ActionRowBuilder().addComponents([btn1, btn2])
    await interaction.update({
      embeds: [embedFolup],
      components: [bttn]
    })
  }
}