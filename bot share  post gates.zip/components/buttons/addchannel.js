const { EmbedBuilder, ModalBuilder, ActionRowBuilder, TextInputBuilder, TextInputStyle } = require("discord.js")
const { NamaBot, OwnerID } = require("../../settings.js")

module.exports = {
  data: {
    name: "inputchannel"
  },
  async execute(interaction, client) {
    const embedGagal = new EmbedBuilder()
    .setColor("Red")
    .setTitle("<:silang:1354994994087329924> Akses Ditolak")
    .setDescription(`Hanya owner yang bisa mengakses perintah ini!`)
    .setTimestamp()
    .setFooter({text: NamaBot, iconURL: client.user.displayAvatarURL()})
    if (interaction.user.id !== OwnerID) return await interaction.reply({
      embeds: [embedGagal],
      ephemeral: true
    })
    let addModal = new ModalBuilder()
    .setTitle("Add Channel Auto-Post")
    .setCustomId("addchannelmodal")
    let channelId = new TextInputBuilder()
    .setCustomId("channelid")
    .setLabel("Channel ID")
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    let messageChannel = new TextInputBuilder()
    .setCustomId("messagechannel")
    .setLabel("Pesan")
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true)
    let interval = new TextInputBuilder()
    .setCustomId("interval")
    .setLabel("Interval (Minimum 3600 Detik)")
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    let channel = new ActionRowBuilder().addComponents(channelId)
    let msg = new ActionRowBuilder().addComponents(messageChannel)
    let interv = new ActionRowBuilder().addComponents(interval)
    addModal.addComponents([channel, msg, interv])
    await interaction.showModal(addModal)
  }
}