const { EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require("discord.js")
const { NamaBot, OwnerID } = require("../../settings.js")
const fs = require("fs")

module.exports = {
  data: {
    name: "btnstop"
  },
  async execute(interaction, client) {
    const embedGagal = new EmbedBuilder()
    .setColor("Red")
    .setTitle("<:silang:1354994994087329924> Akses Ditolak")
    .setDescription(`Hanya owner yang bisa mengakses perintah ini!`)
    .setTimestamp()
    .setFooter({text: NamaBot, iconURL: client.user.displayAvatarURL()})
    if (interaction.user.id !== OwnerID) return await interaction.reply({
      embeds: [embedGagal],
      ephemeral: true
    })
    if (fs.existsSync("./Database/Selection.json")) {
      let Data = JSON.parse(fs.readFileSync("./Database/Selection.json"))
      let Channel = JSON.parse(fs.readFileSync("./Database/Channel.json"))
      let ps = null
      Object.keys(Channel).forEach((u) => {
        if (Channel[u].channelid === Data.channelid) ps = u
      })
      if (ps !== null) {
        let hbtn
        Channel[ps].status = false
        fs.writeFileSync("./Database/Channel.json", JSON.stringify(Channel, null, 3))
    let embP = new EmbedBuilder()
        .setColor("Blue")
        .setTitle("<:mcdirt:1355007332886777946> Informasi Channel")
        .setDescription(`**Nama:** ${Data.name}
**ID:** ${Data.channelid}
**Status:** ${Channel[ps].status ? "Aktif <:ceklist:1354994363284852808>" : "Nonaktif <:silang:1354994994087329924>"}

<:seru:1355091662954561536> Silahkan pilih menu dibawah ini sesuai kebutuhanmu!`)
if (Channel[ps].status === true) {
hbtn = new ButtonBuilder()
.setCustomId("btnstop")
.setLabel("Stop")
.setStyle(ButtonStyle.Danger)
} else {
  hbtn = new ButtonBuilder()
.setCustomId("btnstart")
.setLabel("Start")
.setStyle(ButtonStyle.Success)
}
let btnedit = new ButtonBuilder()
.setCustomId("btnedit")
.setLabel("Edit")
.setStyle(ButtonStyle.Primary)
let btndelete = new ButtonBuilder()
.setCustomId("btndelete")
.setLabel("Delete")
.setStyle(ButtonStyle.Danger)
let buttons = new ActionRowBuilder().addComponents([hbtn, btnedit, btndelete])
await interaction.update({
  embeds: [embP],
  components: [buttons]
})
}
  }
  }
}