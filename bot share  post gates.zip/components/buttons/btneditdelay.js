const { EmbedBuilder, ModalBuilder, ActionRowBuilder, TextInputBuilder, TextInputStyle } = require("discord.js")
const { NamaBot, OwnerID } = require("../../settings.js")

module.exports = {
  data: {
    name: "btneditdelay"
  }, async execute(interaction, client) {
    const embedGagal = new EmbedBuilder()
    .setColor("Red")
    .setTitle("<:silang:1354994994087329924> Akses Ditolak")
    .setDescription(`Hanya owner yang bisa mengakses perintah ini!`)
    .setTimestamp()
    .setFooter({text: NamaBot, iconURL: client.user.displayAvatarURL()})
    if (interaction.user.id !== OwnerID) return await interaction.reply({
      embeds: [embedGagal],
      ephemeral: true
    })
    let editModal = new ModalBuilder()
    .setTitle("Edit Channel Interval")
    .setCustomId("editchanneldelay")
    let message = new TextInputBuilder()
    .setCustomId("newdelay")
    .setLabel("New Interval (second)")
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    let msg = new ActionRowBuilder().addComponents(message)
    editModal.addComponents([msg])
    await interaction.showModal(editModal)
  }
}