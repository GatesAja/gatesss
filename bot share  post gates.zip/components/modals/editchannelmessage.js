const { EmbedBuilder } = require("discord.js")
const { NamaBot, OwnerID } = require("../../settings.js")
const fs = require("fs")

module.exports = {
  data: {
    name: "editchannelmessage"
  },
  async execute(interaction, client) {
    let newMessage = interaction.fields.getTextInputValue("newmessage")
    let Channel = JSON.parse(fs.readFileSync("./Database/Channel.json"))
    let Data = JSON.parse(fs.readFileSync("./Database/Selection.json"))
    let h = null
    if (Channel.length !== 0) {
      Object.keys(Channel).forEach(async (p) => {
        if (Number(Channel[p].channelid) === Number(Data.channelid)) h = p
      })
      if (h !== null) {
        Channel[h].message = newMessage
        fs.writeFileSync("./Database/Channel.json", JSON.stringify(Channel, null, 3))
        let embedSukses = new EmbedBuilder()
    .setColor("Green")
    .setTitle("<:ceklist:1354994363284852808> Edit Message Berhasil")
    .setDescription(`Berhasil edit message channel auto post`)
    .setTimestamp()
    .setFooter({text: NamaBot, iconURL: client.user.displayAvatarURL()})
    await interaction.reply({
      embeds: [embedSukses]
    })
      }
    }
  }
}