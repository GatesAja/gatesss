const { EmbedBuilder } = require("discord.js")
const { NamaBot, OwnerID } = require("../../settings.js")
const fs = require("fs")
const { fetchChannelByID } = require("../../otherfunction/fetchChannel.js")

module.exports = {
  data: {
    name: "addchannelmodal"
  },
  async execute(interaction, client) {
    let channelId = interaction.fields.getTextInputValue("channelid")
    const embedErr1 = new EmbedBuilder()
    .setColor("Red")
    .setTitle("<:silang:1354994994087329924> Error!!")
    .setDescription(`Channel ID harus berupa angka!`)
    .setTimestamp()
    .setFooter({text: NamaBot, iconURL: client.user.displayAvatarURL()})
    
    let message = interaction.fields.getTextInputValue("messagechannel")
    let intervall = interaction.fields.getTextInputValue("interval")
    const embedErr2 = new EmbedBuilder()
    .setColor("Red")
    .setTitle("<:silang:1354994994087329924> Error!!")
    .setDescription(`Interval harus berupa angka!`)
    .setTimestamp()
    .setFooter({text: NamaBot, iconURL: client.user.displayAvatarURL()})
    if (isNaN(intervall)) return await interaction.reply({
      embeds: [embedErr],
      ephemeral: true
    })
    channelId = channelId.split(",")
    let u = 0
    let Channel = JSON.parse(fs.readFileSync("./Database/Channel.json"))
    Object.keys(channelId).forEach(async (h) => {
      let chn = await fetchChannelByID(channelId[h])
      let gid = chn.guild_id
      if (Number(intervall) < 120) {
      if (chn.rateLimitPerUser < 120) {
        intervall = 120
      } else {
      intervall = chn.rateLimitPerUser
      }
    }
    if (Channel.length !== 0) {
      Object.keys(Channel).forEach(async (p) => {
        if (Number(Channel[p].channelid) === Number(channelId[h])) return 
      })
    }
    let data = {
      status: false,
      serverid: gid,
      name: chn.name,
      channelid: channelId[h],
      message: message,
      interval: Number(intervall)
    }
    Channel.push(data)
    fs.writeFileSync("./Database/Channel.json", JSON.stringify(Channel, null, 3))
    u++
    })
    let embedSukses = new EmbedBuilder()
    .setColor("Green")
    .setTitle("<:ceklist:1354994363284852808> Add Channel Berhasil")
    .setDescription(`Berhasil add channel ke auto post`)
    .setTimestamp()
    .setFooter({text: NamaBot, iconURL: client.user.displayAvatarURL()})
    await interaction.reply({
      embeds: [embedSukses],
      ephemeral: true
    })
  }
}