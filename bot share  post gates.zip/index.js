const { Client, Collection, GatewayIntentBits } = require("discord.js")
const { TokenBot, ClientID, NamaBot, OwnerID } = require("./settings.js")
const { Webhook, MessageBuilder } = require('discord-webhook-node')
const axios = require("axios")
const { fetchChannelByID } = require("./otherfunction/fetchChannel.js")
const fs = require("fs")
const client = new Client({
  intents: [GatewayIntentBits.Guilds]
})
client.commands = new Collection()
client.buttons = new Collection()
client.selectMenus = new Collection()
client.modals = new Collection()
client.listCommand = []

const functionFolder = fs.readdirSync("./function")
for (let folder of functionFolder) {
  const fileFunction = fs.readdirSync(`./function/${folder}`).filter((file) => file.endsWith(".js"))
  for (let file of fileFunction) {
    require(`./function/${folder}/${file}`)(client)
  }
}

let channelConfigs = []
let activeIntervals = new Map()


function loadConfig() {
    try {
        const rawData = fs.readFileSync('./Database/Channel.json', 'utf-8')
        const newConfig = JSON.parse(rawData)

        console.log("🔄 Config reloaded:", newConfig)
        updateIntervals(newConfig)
    } catch (error) {
        console.error("❌ Failed to load config:", error)
    }
}

// Fungsi untuk memperbarui interval secara real-time
function updateIntervals(newConfigs) {
    newConfigs.forEach(config => {
        if (!activeIntervals.has(config.channelid)) {
            console.log(`✅ Starting auto post for channel ${config.channelid}`)
            startInterval(config)
        } else {
            // Jika interval sudah ada, periksa apakah perlu diperbarui
            const currentConfig = channelConfigs.find(c => c.id === config.channelid)
            if (JSON.stringify(currentConfig) !== JSON.stringify(config)) {
                console.log(`🔄 Updating auto post for channel ${config.channelid}`)
                clearInterval(activeIntervals.get(config.channelid))
                startInterval(config)
            }
        }
    })

    // Hentikan interval yang tidak ada dalam config terbaru
    activeIntervals.forEach((intervalId, channelId) => {
        if (!newConfigs.find(config => config.channelid === channelId)) {
            console.log(`🛑 Stopping auto post for channel ${channelId}`)
            clearInterval(intervalId)
            activeIntervals.delete(channelId)
        }
    })

    channelConfigs = newConfigs // Simpan konfigurasi terbaru
}

// Fungsi untuk memulai interval pengiriman pesan
async function startInterval(config) {
    const channel = await fetchChannelByID(config.channelid)
    if (!channel) {
        console.error(`⚠️ Channel ${config.channelid} not found or bot has no permission!`)
        return
    }
    // 🔹 Kirim pesan pertama kali sebelum interval berjalan
    sendMessage(channel, config)

    // 🔹 Set interval untuk pengiriman berikutnya
    const intervalId = setInterval(() => sendMessage(channel, config), config.interval*1000)
    activeIntervals.set(config.channelid, intervalId)
}

// Fungsi untuk mengirim pesan ke channel
async function sendMessage(channel, config) {
    if (!channel) return
    if (!config.status) return
    const message = config.message
    let Main = JSON.parse(fs.readFileSync("./Database/Main.json"))
    try {
const response = await axios.post(`https://discord.com/api/v10/channels/${config.channelid}/messages`, { content: message },
{
headers: {
Authorization: `${Main.token}`,
'Content-Type': 'application/json',
},
            })
                            let emb = new MessageBuilder()
              .setTitle("Auto Post Log")
              .setColor("#3598DB")
              .addField('Posted By', `<@945625990841901056>`)
              .addField('<:channel:1356767494672486481> Channel', `https://discord.com/channels/${config.serverid}/${config.channelid}`)
              .addField('<:jam:1356767526469767361> Timestamp', `${response.data.timestamp}`)
              .addField('GATES JASA', `https://discord.gg/dJjgmvUksz`)
.setFooter(NamaBot, client.user.displayAvatarURL())
.setTimestamp()
if (Main.webhookurl === "" || !Main.webhookurl.includes("https://discord")) {
  client.users.send(OwnerID, {
    embeds: [emb]
  })
} else {
  const hook = new Webhook(Main.webhookurl)
  hook.send(emb)
}
    } catch (error) {
      if (error.response.data.code === 0 || error.response.data.code === 50013 || error.response.data.code === 10013 || error.response.data.code === 20001 || error.response.data.code === 20028) {
              let dh = new MessageBuilder()
              .setTitle("Auto Post Log")
              .setColor("#F23F43")
.setDescription(`<:silang:1354994994087329924> Gagal mengirim auto post
Reason: ${error.response.data.message}`)
.setImage("https://share.creavite.co/67ec73ad71cd7c246f7c07c0.gif")
.setFooter(NamaBot, client.user.displayAvatarURL())
.setTimestamp()
if (Main.webhookurl === "" || !Main.webhookurl.includes("https://discord")) {
  client.users.send(OwnerID, {
    embeds: [dh]
  })
} else {
  const hook = new Webhook(Main.webhookurl)
  hook.send(dh)
}
            }
    }
}

// Pantau perubahan file config.json secara real-time
fs.watchFile('./Database/Channel.json', { interval: 1000 }, (curr, prev) => {
    if (curr.mtime !== prev.mtime) {
        console.log("🔄 Config file changed, reloading...")
        loadConfig()
    }
})


client.handlerEvents()
client.handlerCommands()
client.handlerComponents()
client.login(TokenBot)