const TokenBot = ""
const ClientID = "1377781581577715935"
const NamaBot = "GatesPost"
const OwnerID = "945625990841901056"

module.exports = { TokenBot, ClientID, NamaBot, OwnerID }