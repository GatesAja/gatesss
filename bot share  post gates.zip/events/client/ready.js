const ora = require('ora');

module.exports = {
  name: "ready",
  once: true,
  async execute(client) {
    client.user.setPresence({
      activities: [{name: "Online Bot Gates Post", type: 1}],
      status: "idle"
    })
  }
}